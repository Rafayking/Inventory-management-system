import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InventoryManagementGUI {
    private JFrame frame;
    private InventoryManagementSystem ims;
    private JTextField itemIdField, itemNameField, itemQuantityField, removeIdField;

    public InventoryManagementGUI() {
        ims = new InventoryManagementSystem();
        initializeUI();
        addSampleData();
    }

    private void initializeUI() {
        frame = new JFrame("Inventory Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2, 10, 10));

        // Add Item
        panel.add(new JLabel("Item ID:"));
        itemIdField = new JTextField(10);
        panel.add(itemIdField);
        panel.add(new JLabel("Item Name:"));
        itemNameField = new JTextField(10);
        panel.add(itemNameField);
        panel.add(new JLabel("Quantity:"));
        itemQuantityField = new JTextField(10);
        panel.add(itemQuantityField);
        JButton addItemBtn = new JButton("Add Item");
        panel.add(addItemBtn);

        // Remove Item
        panel.add(new JLabel("Item ID to Remove:"));
        removeIdField = new JTextField(10);
        panel.add(removeIdField);
        JButton removeItemBtn = new JButton("Remove Item");
        panel.add(removeItemBtn);

        // Display Items
        JButton displayBtn = new JButton("Display Inventory");
        panel.add(displayBtn);

        // Action Listeners
        addItemBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String itemId = itemIdField.getText();
                String itemName = itemNameField.getText();
                int quantity = Integer.parseInt(itemQuantityField.getText());
                ims.addItem(new Item(itemId, itemName, quantity));
                JOptionPane.showMessageDialog(frame, "Item added successfully!");
                clearFields(itemIdField, itemNameField, itemQuantityField);
            }
        });

        removeItemBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String itemId = removeIdField.getText();
                ims.removeItem(itemId);
                JOptionPane.showMessageDialog(frame, "Item removed (if found)!");
                clearFields(removeIdField);
            }
        });

        displayBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String inventory = ims.displayItems(); // Get the inventory string from the system
                JOptionPane.showMessageDialog(frame, inventory); // Display it
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }

    private void addSampleData() {
        ims.addItem(new Item("I1", "Laptop", 10));
        ims.addItem(new Item("I2", "Mouse", 50));
    }

    private void clearFields(JTextField... fields) {
        for (JTextField field : fields) {
            field.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new InventoryManagementGUI();
            }
        });
    }
}