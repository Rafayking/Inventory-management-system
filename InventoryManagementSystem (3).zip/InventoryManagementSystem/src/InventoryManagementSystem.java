import java.util.ArrayList;
import java.util.List;

public class InventoryManagementSystem {
    private List<Item> items;

    public InventoryManagementSystem() {
        items = new ArrayList<>();
    }

    public void addItem(Item item) { items.add(item); }
    public void removeItem(String itemId) { items.removeIf(item -> item.getItemId().equals(itemId)); }
    public Item findItem(String itemId) {
        for (Item item : items) { if (item.getItemId().equals(itemId)) return item; }
        return null;
    }
    public String displayItems() {
        if (items.isEmpty()) return "No items in inventory.";
        StringBuilder sb = new StringBuilder();
        for (Item item : items) sb.append(item).append("\n");
        return sb.toString();
    }
}